package coding.community.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllersApplicationTests {

	@Test
	void contextLoads() {
	}

}
